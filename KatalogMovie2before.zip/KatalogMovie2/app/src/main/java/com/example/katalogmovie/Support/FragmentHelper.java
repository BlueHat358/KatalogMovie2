package com.example.katalogmovie.Support;

import android.support.v4.app.Fragment;

public class FragmentHelper{
    public static final String KEY_MOVIES = "movies";
    public static final String MOVIE_ARRAY = "array";
}
